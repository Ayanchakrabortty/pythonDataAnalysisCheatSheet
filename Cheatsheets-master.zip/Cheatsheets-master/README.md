# Cheat Sheets
A collection of cheatsheets from various technologies.
- practiceDB.sql => PostgreSQL Cheatsheet
- pandas-intro.ipynd => Pandas Cheatsheet
- numpy-intro.ipynd => Numpy Cheatsheet
- matplotlib-intro.ipynb => Matplotlib Cheatsheet
- intro-python.ipynb => Python Cheatsheet
